﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculadora
{
    class Operaciones
    {
        public double Suma(double a, double b)
        {
            return a + b;
        }
        public double Resta(double a, double b)
        {
            return a - b;
        }
        public double Multiplicación(double a, double b)
        {
            return a * b;
        }
        public double División(double a, double b)
        {
            return a / b;
        }


    }
}
